import { AboutModule } from './about/about.module';
import { appRouting } from './app.routing';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import {BrowserModule} from '@angular/platform-browser'
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './Home/Home.component';
import { NotFoundComponentComponent } from './NotFoundComponent/NotFoundComponent.component';
import{FormsModule} from "@angular/forms";


@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    AboutModule,
    appRouting
    
  ],
 declarations:[
    AppComponent,
    ContactComponent,
    HomeComponent,
    NotFoundComponentComponent
],
    bootstrap:[AppComponent]
})
export class AppModule { }