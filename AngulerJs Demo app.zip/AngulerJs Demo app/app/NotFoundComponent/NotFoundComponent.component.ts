import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-NotFoundComponent',
  templateUrl: '/app/NotFoundComponent/NotFoundComponent.component.html'
   
})
export class NotFoundComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}