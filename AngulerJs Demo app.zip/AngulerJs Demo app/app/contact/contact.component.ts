import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: '/app/contact/contact.component.html',
 
})
export class ContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}