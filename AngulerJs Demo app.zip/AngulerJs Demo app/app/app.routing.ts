import { AboutComponent } from './about/about.component';
import { NotFoundComponentComponent } from './NotFoundComponent/NotFoundComponent.component';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './Home/Home.component';
import {RouterModule,Routes} from '@angular/router';
import { ModuleWithProviders} from "@angular/core";
const appRoutes:Routes=[
    {path:'',redirectTo:'Home',pathMatch:'full'},
    {path:'Home',component:HomeComponent},
    {path:'contact', component:ContactComponent },
     {path:'about', component:AboutComponent },
    {path:'**', component:NotFoundComponentComponent}    

];
export const appRouting = RouterModule.forRoot(appRoutes);