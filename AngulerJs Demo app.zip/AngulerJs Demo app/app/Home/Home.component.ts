import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Home',
  templateUrl: '/app/Home/Home.component.html',
  
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}