import { Component} from '@angular/core';

@Component({
  selector: 'app-app',
  templateUrl: '/app/app.component.html',
 
})
export class AppComponent {
}