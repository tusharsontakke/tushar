import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: '../app/about/about.component.html',
 
})
export class AboutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}