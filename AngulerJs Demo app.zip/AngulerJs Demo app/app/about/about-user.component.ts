import { User } from './../Shared/models/user';

import { Component, OnInit } from '@angular/core';

@Component({
   
   selector: 'about-ser',
   templateUrl: '../app/about/aboutuser.component.html',
   styles:[
       `img{
           max-width:30%;
           margin:20px auto;
       }`
   ]
})
export class AboutUserComponent implements OnInit {
user:User;

   constructor() { }

   ngOnInit() { }
}