import { AboutUserComponent } from './about-user.component';
import { AboutSectionComponent } from './about-section.component';
import { AboutComponent } from './about.component';
import { aboutRouting } from './about.routing';
import { NgModule } from '@angular/core';
import {CommonModule} from '@angular/common';



@NgModule({
    imports:[
        CommonModule,
        aboutRouting
    ],
    declarations:[
        AboutComponent,
        AboutSectionComponent,
        AboutUserComponent
    ]
})
export class AboutModule { }
